# Our Class — Orientation 2026 Website

A responsive static website for your class, built with plain HTML, CSS and JavaScript. All five supplied photos are included in `assets/`.

## Preview on your computer
1. Extract the ZIP file.
2. Open the `bootcamp_class_website` folder.
3. Double-click `index.html` to open it in Chrome.

## Publish using GitHub Pages
1. Open your GitHub repository.
2. Upload `index.html` and the entire `assets` folder (keep the folder and filenames unchanged).
3. Commit the changes to the `main` branch.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait a few minutes and refresh the Pages screen; GitHub will show your site URL.

## Important
- Do not enter `hussnain` in the **Custom domain** field unless you own a real domain name. Leave that field empty for the default `*.github.io` URL.
- The faculty section uses a descriptive placeholder because the speaker's name/designation was not provided. Edit `index.html` and replace that text once you confirm the official details.
- The group photos show classmates. Share the site publicly only if you have permission to publish the photos.
- This is a static website; it does not collect names, phone numbers or other visitor information.
